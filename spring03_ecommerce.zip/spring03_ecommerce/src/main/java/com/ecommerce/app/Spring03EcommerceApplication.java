package com.ecommerce.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring03EcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring03EcommerceApplication.class, args);
	}

}
