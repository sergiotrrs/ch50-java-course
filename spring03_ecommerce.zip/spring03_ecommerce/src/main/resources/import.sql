
INSERT INTO products(id, title, description, price) VALUES (1, 'Bicicleta', 'Bicicleta rodada 25', 4500.50), (2, 'Bicicleta Montaña', 'Bicicleta todo terreno rodada 26', 5800.75);
INSERT INTO products(id, title, description, price) VALUES (3, 'Patineta', 'Patineta profesional', 1500.90);
INSERT INTO products(id, title, description, price) VALUES (4, 'Casco', 'Casco de seguridad para bicicleta', 800.50);
INSERT INTO products(id, title, description, price) VALUES (5, 'Guantes', 'Guantes antideslizantes para ciclismo', 450.75);
INSERT INTO products(id, title, description, price) VALUES (6, 'Rodilleras', 'Rodilleras para deportes extremos', 650.30);
INSERT INTO products(id, title, description, price) VALUES (7, 'Monopatín', 'Monopatín estilo clásico', 2300.00);
INSERT INTO products(id, title, description, price) VALUES (8, 'Bicicleta Eléctrica', 'Bicicleta con batería integrada', 12500.95);
INSERT INTO products(id, title, description, price) VALUES (9, 'Cámara', 'Cámara de aire para bicicleta', 300.45);
INSERT INTO products(title, description, price) VALUES ('Luz Frontal', 'Luz LED para bicicleta', 250.00);
INSERT INTO products(title, description, price) VALUES ('Reflector', 'Reflector trasero rojo para bicicleta', 180.35);